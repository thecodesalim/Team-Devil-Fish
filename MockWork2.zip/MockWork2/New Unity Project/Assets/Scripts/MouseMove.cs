﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseMove : MonoBehaviour {

    // Use this for initialization
    private Camera cam;
    public Vector3 MousePos;

    void Start()
    {
        cam = Camera.main;
    }


    // Update is called once per frame
    void Update () {

        MousePos = Input.mousePosition;        
        gameObject.transform.position = cam.ScreenToWorldPoint(new Vector3(MousePos.x, MousePos.y, cam.nearClipPlane)); ;
    }
}
