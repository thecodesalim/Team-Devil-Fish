﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectBox : MonoBehaviour {
    float MinX = -9.5f, MinY = -4.5f, MaxX = 9.5f, MaxY = 4.5f;
    GameObject Cursor;

    // Use this for initialization
    void Start () {
        GetCursor();
    
    }
    
    void GetCursor ()
    {
        Cursor = GameObject.Find("Cursor");

    }
	
	// Update is called once per frame
	void Update () {
        //MouseMove mousemove = Cursor.GetComponent<MouseMove>();
        //mousemove.MousePos
    }
}
