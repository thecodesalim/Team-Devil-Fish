﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnDevilFish : MonoBehaviour {

    public GameObject PrefabDevilFish1;
    // Use this for initialization
    void Start()
    {
        int X = -10, Y = Random.Range(-4, 6);

        Instantiate(PrefabDevilFish1, new Vector3(0.5f + (X), 0.5f - (Y), 0f), Quaternion.identity);

    }

    // Update is called once per frame
    void Update () {
		
	}
}
