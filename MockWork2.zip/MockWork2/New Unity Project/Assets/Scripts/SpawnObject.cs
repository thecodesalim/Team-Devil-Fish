﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnObject : MonoBehaviour {

    public GameObject PrefabWallTest;
    // Use this for initialization
    void Start () {
        int X = -9, Y = -4;

        Instantiate(PrefabWallTest, new Vector3(0.5f + (X), 0.5f - (Y), 0f), Quaternion.identity);
       
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
