Backyard Top-Down Tiles - Pixel Art - Free Edition

2015 - Kittens and Elves at Work

http://www.keawstudio.com
contact@keawstudio.com

The backyard tiles are available in the following formats:

** full atlas with all titles 
- backyard.png
- with the following import options:
	Texture Type: Sprite
	Sprite Mode: Multiple
	Pixels per unit: 48
	Generate Mip Maps: No
	Filter Mode: Point
	Format: TrueColor
	
** each title in separate file 
- folder Separate Tiles
- files from backyard_00 to backyard_89. 
- There is more titles than the atlas image because some details have their own files.
- Same importing options as the full atlas, except that each file is in Single mode.

** source file made with PyxelEdit 
- folder Additional Files
- file backyard.pyxel

All titles have the size 48x48. Some tiles have transparent background.