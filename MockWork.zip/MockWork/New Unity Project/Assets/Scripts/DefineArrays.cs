﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DefineArrays : MonoBehaviour {
    void Start()
    {
        int HTiles = 16;
        int WTiles = 16;


        int[,] BuildTiles = new int[HTiles, WTiles];
        int[,] PathfindingTiles = new int[HTiles, WTiles];

        for (int i = 0; i < HTiles; i++)
        {
            BuildTiles[i, 0] = -1; //water, unbuildable   
}
    }

    // Update is called once per frame
    void Update()
    {

    }
}
